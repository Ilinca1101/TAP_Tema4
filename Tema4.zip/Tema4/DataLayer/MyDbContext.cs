﻿using DataLayer.Models;
using Microsoft.EntityFrameworkCore;

namespace DataLayer
{
    // dotnet ef migrations add Initial
    // dotnet ef database update
    public class MyDbContext : DbContext
    {
        //private readonly string _windowsConnectionString = @"Server=.\SQLExpress;Database=Lab5Database1;Trusted_Connection=True;TrustServerCertificate=true";
        private readonly string _windowsConnectionString = @"Server=localhost\SQLEXPRESS;Database=Lab5Database1;Trusted_Connection=True;TrustServerCertificate=True;";

        public DbSet<User> Users { get; set; }
        public DbSet<UserType> UserTypes { get; set; }
        public DbSet<Author> Authors { get; set; }
        public DbSet<Book1> Books { get; set; }
        public DbSet<Library> Librarys { get; set; }
        public DbSet<Reader> Readers { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_windowsConnectionString);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<User>()
                .HasOne(f => f.Type)
                .WithMany(c => c.Users)
                .HasForeignKey(f => f.TypeId);


            builder.Entity<Author>()
                .HasOne(e => e.Library)
                .WithOne(o => o.Author)
                .HasForeignKey<Library>(o => o.AuthorId)
                .HasPrincipalKey<Author>(e => e.Id);

            builder.Entity<Reader>()
                .HasOne(o => o.Author)
                .WithMany(e => e.Readers)
                .HasForeignKey(o => o.AuthorId);

            builder.Entity<Book1>()
                .HasMany(p => p.Readers)
                .WithMany(o => o.Books1)
                .UsingEntity<ReadBook>();

            builder.Entity<Author>().HasData(new Author[0]);
            builder.Entity<Library>().HasData(new Library[0]);
            builder.Entity<Book1>().HasData(new Book1[0]);
            builder.Entity<Reader>().HasData(new Reader[0]);

            Author[] authors =
            {
                new Author("Mihai", 44),
                new Author("Ion", 52),
                new Author("George", 68)
            };

            builder.Entity<Author>().HasData(authors);

            builder.Entity<Library>().HasData(
                   new Library("Book, Notebook, Pen", authors[0].Id),
                   new Library("Book, Notebook", authors[1].Id),
                   new Library("Pen", authors[2].Id)
                );

            Book1[] books =
            {
                new Book1("And There Were None", "Mystery", 55),
                new Book1("Harry Potter: The Goblet Of Fire", "SF", 34),
                new Book1("The Murder on Orient Express", "Police", 70),
                new Book1("Pride and Prejudice", "Romance novel", 67)
            };

            builder.Entity<Book1>().HasData(books);

                Reader[] readers =
            {
                new Reader(DateTime.Now, authors[0].Id),
                new Reader(DateTime.Now, authors[1].Id),
                new Reader (DateTime.Now, authors[2].Id),
                new Reader(DateTime.Now, authors[0].Id),
            };

            builder.Entity<Reader>().HasData(readers);

            builder.Entity<ReadBook>().HasData(
                    new ReadBook(readers[0].Id, books[0].Id),
                    new ReadBook(readers[0].Id, books[1].Id),
                    new ReadBook(readers[1].Id, books[2].Id),
                    new ReadBook(readers[2].Id, books[2].Id),
                    new ReadBook(readers[2].Id, books[3].Id),
                    new ReadBook(readers[3].Id, books[0].Id),
                    new ReadBook(readers[3].Id, books[2].Id),
                    new ReadBook(readers[3].Id, books[3].Id)
                );
        }
    }
}
