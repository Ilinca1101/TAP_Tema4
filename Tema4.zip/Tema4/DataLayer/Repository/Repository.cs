﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Linq.Expressions;

namespace DataLayer.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
       
        private readonly MyDbContext _context;
        private readonly DbSet<T> _entities;

        public Repository(MyDbContext context)
        {
            _context = context;
            _entities = context.Set<T>();
        }

        public T GetById(Guid id)
        {
            return _entities.Find(id);
        }

        public IEnumerable<T> GetAll()
        {
            return _entities.ToList();
        }

        public IEnumerable<T> Find(Expression<Func<T, bool>> predicate)
        {
            return _entities.Where(predicate);
        }

        public void Add(T entity)
        {
            _entities.Add(entity);
        }

        public void Update(T entity)
        {
            _entities.Update(entity);
        }

        public void Remove(T entity)
        {
            _entities.Remove(entity);
        }

        public void Delete(Guid id)
        {
            var entity = _entities.Find(id);
            if (entity != null)
            {
                _entities.Remove(entity);
            }
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }

        public IEnumerable<T> Include<TResult>(Expression<Func<T, ICollection<TResult>>> predicate)
        {
            return _entities.Include(predicate);
        }



        public T FindFirst(Expression<Func<T, bool>> predicate)
        {
            var values = Find(predicate);
            if (!values.IsNullOrEmpty())
            {
                return values.First();
            }

            return null;
        }
        public IEnumerable<T> GetByIds(ICollection<Guid> ids)
        {
            throw new NotImplementedException();
        }
    }
}
