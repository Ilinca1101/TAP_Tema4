﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class Library
    {
        public int Id { get; set; }
        public string Collection { get; set; }
        public Guid AuthorId { get; set; }
        public Author Author { get; set; }

        public Library(string collection, Guid authorId)
        {
            Collection = collection; ;
            AuthorId = authorId;
        }
    }
}
