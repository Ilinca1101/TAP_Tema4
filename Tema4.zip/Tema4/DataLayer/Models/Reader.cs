﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class Reader
    {
        public int Id { get; set; }
        public DateTime DateTime { get; set; }
        public Guid AuthorId { get; set; }
        public Author Author { get; set; }
        public ICollection<Book1> Books1 { get; }
        public IEnumerable<object> Book1 { get; set; }

        public Reader(DateTime dateTime, Guid authorId)
        {
            DateTime = dateTime;
            AuthorId = authorId;
            Books1 = new List<Book1>();
        }
    }
}
