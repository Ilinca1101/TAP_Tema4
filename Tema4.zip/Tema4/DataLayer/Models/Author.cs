﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class Author
    {
        
        public string Name { get; set; }
        public int Age { get; set; }
        public Library Library { get; set; }
        public Guid Id { get; set; }

        public ICollection<Reader> Readers { get; }
        public Author(string name, int age)
        {
            Name = name;
            Age = age;
            Readers = new List<Reader>();
        }
    }
}
