﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class ReadBook
    {
        public Guid Id { get; set; }
        public Guid ReaderId { get; set; }
        public Guid BookId { get; set; }

        public ReadBook(int Id, int id)
        {

        }

        public ReadBook(Guid readerId, Guid bookId)
        {
            ReaderId = readerId;
            BookId = bookId;
        }
    }
}
