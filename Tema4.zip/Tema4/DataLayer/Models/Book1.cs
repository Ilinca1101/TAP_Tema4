﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class Book1
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Genre { get; set; }
        public float Price { get; set; }

        public ICollection<Reader> Readers { get; }

        public Book1(string title, string genre, float price)
        {
            Title = title;
            Genre = genre;
            Price = price;
            Readers = new List<Reader>();
        }
    }
}
