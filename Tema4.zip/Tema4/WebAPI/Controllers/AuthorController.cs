﻿using DataLayer.Models;
using DataLayer.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AuthorController : ControllerBase
    {
        private IRepository<Author> _authorRepository;

        public AuthorController(IRepository<Author> authorRepository)
        {
            _authorRepository = authorRepository;
        }

        [HttpGet("getall")]
        public IEnumerable<AuthorDto> GetAll()
        {
            return _authorRepository.GetAll()
                .Select(author => new AuthorDto(author.Name, author.Age));
        }

        [HttpPost("insert")]
        public void Insert(AuthorDto author)
        {
            _authorRepository.Add(new Author(
                author.Name,
                author.Age));

            _authorRepository.SaveChanges();
        }

        [HttpPut("update")]
        public ObjectResult Update(Guid authorId, AuthorDto author)
        {
            var authorFromDb = _authorRepository.GetById(authorId);

            if (authorFromDb == null)
            {
                return NotFound("Author not found");
            }

            authorFromDb.Name = author.Name;
            authorFromDb.Age = author.Age;

            _authorRepository.SaveChanges();

            return Ok("Author updated succesfully");
        }

        [HttpDelete("delete")]
        public ObjectResult Delete(Guid authorId)
        {
            var authorFromDb = _authorRepository.GetById(authorId);

            if (authorFromDb == null)
            {
                return NotFound("Author not found");
            }

            _authorRepository.Remove(authorFromDb);
            _authorRepository.SaveChanges();

            return Ok("Author removed succesfully");
        }
    }
}
