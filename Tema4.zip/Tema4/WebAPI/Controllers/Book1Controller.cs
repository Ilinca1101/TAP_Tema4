﻿using DataLayer.Models;
using DataLayer.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class Book1Controller : ControllerBase
    {
        private readonly IRepository<Book1> _bookRepository;


        public Book1Controller(IRepository<Book1> bookRepository)
        {
            _bookRepository = bookRepository;
        }

        [HttpGet("getall")]
        public IEnumerable<Book1Dto> GetAll()
        {
            return _bookRepository.GetAll()
                .Select(book => new Book1Dto(book.Title, book.Genre, book.Price));
        }

        [HttpPost("insert")]
        public void Insert(Book1Dto book)
        {
            _bookRepository.Add(new Book1(
                book.Title,
                book.Genre,
                book.Price));

            _bookRepository.SaveChanges();
        }

        [HttpPut("update")]
        public ObjectResult Update(Guid bookId, Book1Dto book)
        {
            var bookFromDb = _bookRepository.GetById(bookId);

            if (bookFromDb == null)
            {
                return NotFound("Book not found");
            }

            bookFromDb.Title = book.Title;
            bookFromDb.Genre = book.Genre;
            bookFromDb.Price = book.Price;

            _bookRepository.SaveChanges();

            return Ok("Book updated succesfully");
        }

        [HttpDelete("delete")]
        public ObjectResult Delete(Guid bookId)
        {
            var bookFromDb = _bookRepository.GetById(bookId);

            if (bookFromDb == null)
            {
                return NotFound("Book not found");
            }

            _bookRepository.Remove(bookFromDb);
            _bookRepository.SaveChanges();

            return Ok("Book removed succesfully");
        }
    }
}
