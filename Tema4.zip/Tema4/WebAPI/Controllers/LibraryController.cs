﻿using DataLayer.Models;
using DataLayer.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class LibraryController : ControllerBase
    {
        private readonly IRepository<Library> _libraryRepository;

        public LibraryController(IRepository<Library> libraryRepository)
        {
            _libraryRepository = libraryRepository;
        }

        [HttpGet("getall")]
        public IEnumerable<LibraryDto> GetAll()
        {
            return _libraryRepository.GetAll()
                .Select(library => new LibraryDto(library.Collection, library.AuthorId));
        }

        [HttpPost("insert")]
        public void Insert(LibraryDto library)
        {
            _libraryRepository.Add(new Library(library.Collection, library.AuthorId));
            _libraryRepository.SaveChanges();
        }

        [HttpPut("update")]
        public ObjectResult Update(Guid libraryId, LibraryDto library)
        {
            var libraryFromDb = _libraryRepository.GetById(libraryId);

            if (libraryFromDb == null)
            {
                return NotFound("Library not found");
            }

            libraryFromDb.Collection = library.Collection;
            libraryFromDb.AuthorId = library.AuthorId;

            _libraryRepository.SaveChanges();

            return Ok("Library updated succesfully");
        }

        [HttpDelete("delete")]
        public ObjectResult Delete(Guid libraryId)
        {
            var libraryFromDb = _libraryRepository.GetById(libraryId);

            if (libraryFromDb == null)
            {
                return NotFound("Library not found");
            }

            _libraryRepository.Remove(libraryFromDb);
            _libraryRepository.SaveChanges();

            return Ok("Library removed succesfully");
        }
    }
}
