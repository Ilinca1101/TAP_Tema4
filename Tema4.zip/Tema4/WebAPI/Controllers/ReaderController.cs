﻿using DataLayer.Models;
using DataLayer.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;
using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ReaderController : ControllerBase
    {
        private readonly IRepository<Reader> _readerRepository;
        private readonly IRepository<Book1> _book1Repository;

        public ReaderController(IRepository<Reader> readerRepository, IRepository<Book1> bookRepository)
        {
            _readerRepository = readerRepository;
            _book1Repository = bookRepository;
        }

        /*[HttpGet("get")] //nu merge
        public IEnumerable<ReaderDto> Get()
        {
            return _readerRepository.Include(o => o.Book1).ToList()


                .Select(o =>
                {
                    return new ReaderDto(
                        o.DateTime,
                        o.AuthorId,
                        o.Book1.Select(p => p.Id).ToList());
                });
        }
        */

        [HttpPost("insert")]
        public ObjectResult Insert(ReaderDto reader)
        {
            Reader newReader = new Reader(
                reader.DateTime,
                reader.AuthorId);

            var books1 = _book1Repository.GetByIds(reader.Book1Ids);

            if (books1 == null || books1.Count() != reader.Book1Ids.Count)
            {
                return NotFound("Book not found");
            }

            foreach (var book1 in books1)
            {
                newReader.Books1.Add(book1);
            }

            _readerRepository.Add(newReader);
            _readerRepository.SaveChanges();

            return Ok("Order inserted succesfully");
        }

        [HttpPut("update")]
        public ObjectResult Update(Guid readerId, ReaderDto reader)
        {
            var readerFromDb = _readerRepository.GetById(readerId);

            if (readerFromDb == null)
            {
                return NotFound("Redaer not found");
            }

            readerFromDb.DateTime = reader.DateTime;
            readerFromDb.AuthorId = reader.AuthorId;

            var books1 = _book1Repository.GetByIds(reader.Book1Ids);

            if (books1 == null)
            {
                return NotFound("Book not found");
            }

            readerFromDb.Books1.Clear();
            foreach (var book1 in books1)
            {
                readerFromDb.Books1.Add(book1);
            }

            _readerRepository.SaveChanges();

            return Ok("Reader updated succesfully");
        }

        [HttpDelete("delete")]
        public ObjectResult Delete(Guid readerId)
        {
            var readerFromDb = _readerRepository.GetById(readerId);

            if (readerFromDb == null)
            {
                return NotFound("Reader not found");
            }

            _readerRepository.Remove(readerFromDb);
            _readerRepository.SaveChanges();

            return Ok("Reader removed succesfully");
        }
    }
}
