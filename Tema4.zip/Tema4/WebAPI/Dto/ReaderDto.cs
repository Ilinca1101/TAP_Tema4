﻿namespace WebAPI.Dto
{
    public class ReaderDto
    {
        public DateTime DateTime { get; set; }
        public Guid AuthorId { get; set; }
        public ICollection<Guid> Book1Ids { get; set; }
        

        public ReaderDto(DateTime dateTime, Guid authorId, ICollection<Guid> bookIds)
        {
            DateTime = dateTime;
            AuthorId = authorId;
            Book1Ids = bookIds;
        }
    }
}
