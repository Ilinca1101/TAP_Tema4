namespace WebAPI.Dto;

public class UserTypeDto
{
    public string Name { get; set; }
}