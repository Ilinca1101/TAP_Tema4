﻿using DataLayer.Models;

namespace WebAPI.Dto
{
    public class LibraryDto
    {
        public string Collection { get; set; }
        public Guid AuthorId { get; set; }

        public LibraryDto(string collection, Guid authorId)
        {
            Collection = collection;
            AuthorId = authorId;
        }
    }
}
