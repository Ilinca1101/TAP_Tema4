﻿using DataLayer.Models;

namespace WebAPI.Dto
{
    public class Book1Dto
    {
        public string Title { get; set; }
        public string Genre { get; set; }
        public float Price { get; set; }

        public Book1Dto(string title, string genre, float price)
        {
            Title = title;
            Genre = genre;
            Price = price;
        }
    }
}
